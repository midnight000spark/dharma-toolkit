# Исследование: Внешняя верификация дат бонского (Юнгдрунг Бон) календаря на 2026–2027

Дата исследования: 2026-09-24
Источников проверено: 12 (независимых: 8)
Запросы: 25 формулировок (англ. + рус. контекст), включая «Bon Losar 2026», «Zhang Zhung Losar 2026/2027», «Tonpa Shenrab birthday/parinirvana 2026/2027», «Chotrul Duchen 2026/2027», «Bird arrival festival Bon», «Sidpa Gyalmo Cham 2027», «Tibetan lunar calendar 2027»
Источник данных: Firecrawl (search + scrape); астрономические сверки — открытые лунные календари (TheSkyLive, Griffith Observatory, Catalina, fullmoon.info)

---

## Ключевой вопрос: бонский Лосар 2026 = 19.01.2026?

**ПОДТВЕРЖДЕНО.** Бонский (Чжан Чжун) Лосар 2026 = **19 января 2026**, а не 18 февраля.

- **ravencypresswood.com** (Nine Ways, авторитетный ресурс по Юнгдрунг Бон): «The 1st day of the 12th lunar month is celebrated as New Year's Day according to the custom of the ancient land of Zhang Zhung. In 2026, this date coincides with January 19th on the Western calendar.» [СРЕДНЯЯ]
- **FPYB / yungdrungbon.co.uk** (Foundation for the Preservation of Yungdrung Bön, по устному объяснению Друбдра Кхенпо Цультрим Тензина Ринпоче, аббата Тритэн Норбутсе): подтверждает, что Чжан Чжун Лосар — 1-й день 12-го лунного месяца. [ВЫСОКАЯ]

### Соотношение «Чжан Чжун Лосар» и «Хорда Лосар»

- **Чжан Чжун Лосар** (бонский Новый год, он же Bön Losar / Sonam Losar / Lambing New Year) — **1-й день 12-го лунного месяца**. Это изначальный бонский Новый год по Чжанчжунгскому календарю.
- **Хорда Лосар** (тибетский/«Королевский» Новый год) — **1-й день 1-го лунного месяца**, на один лунный месяц позже.
- Причина сдвига (FPYB, по Тритэн Норбутсе): в XIII веке монголы, победив тибетцев, отменили Чжанчжунгский календарь и **отодвинули Новый год на один месяц вперёд**; эта система известна как монгольская астрологическая система **Хорда** (Tib. hor-zla) и используется для расчёта текущего тибетского Нового года. [ВЫСОКАЯ]
- ravencypresswood подтверждает: «During the period of the Mongol-backed Sakya rule of Tibet, use of the Zhang Zhung based calendrical system was ended... The 1st lunar day of the 1st lunar month was changed to be one month later... In 2026, this lunar day coincides with February 18th.» [СРЕДНЯЯ]

**Вывод:** F-48 проекта корректен — бонский Чжанчжунг-Лосар 2026 = 19 января, тибетский Лосар = 18 февраля. Это два разных праздника, разнесённых на один лунный месяц.

---

## Найденные данные

| № | Праздник (лунный день) | Дата проекта | Статус | Источник |
|---|------------------------|--------------|--------|----------|
| 1 | Чжан Чжун Лосар (1/12) | 2026-01-19 | **ПОДТВЕРЖДЕНО** | [ravencypresswood](https://ravencypresswood.com/2026/01/17/happy-zhang-zhung-new-year/) [СРЕДНЯЯ]; [FPYB](https://yungdrungbon.co.uk/2022/02/02/short-note-on-history-of-zhang-zhung-losar/) [ВЫСОКАЯ] |
| 1 | Чжан Чжун Лосар (1/12) | 2027-01-08 | **ПОДТВЕРЖДЕНО (вывод из лунной таблицы)** | [ravencypresswood лунная таблица](https://ravencypresswood.com/2026/01/24/bringing-meaning-benefit-to-2026-by-taking-a-vow-of-nonviolence-for-1-day-multiple-days-or-a-full-year/): 07.01.2027 = новолуние (30-й день 11-го мес.) → 08.01 = 1-й день 12-го мес. [СРЕДНЯЯ] |
| 2 | Хорда Лосар (1/1) | 2026-02-18 | **ПОДТВЕРЖДЕНО** | [ravencypresswood](https://ravencypresswood.com/2026/02/07/the-tibetan-new-year-removing-obstacles-of-the-past-and-making-aspirations-for-future-2/) [СРЕДНЯЯ]; [Yeru Bon Center](https://yeruboncenter.org/event/tibetan-losar-2026/) [СРЕДНЯЯ]; [Tibet Vista](https://www.tibettravel.org/tibetan-festivals/tibetan-new-year.html) [СРЕДНЯЯ] |
| 2 | Хорда Лосар (1/1) | 2027-02-07 | **ПОДТВЕРЖДЕНО** | [GoToTibet](https://www.gototibet.com/travel-guide/tibetan-new-year-date.html), [qppstudio](https://www.qppstudio.net/global-holidays-observances/losar-tibetan-new-year.htm), [PotalaStore](https://www.potalastore.com/blog/losar-gift-guide-2027/), [Tibetan Nuns Project](https://tnp.org/category/losar-tibetan-new-year/), [ravencypresswood лунная таблица](https://ravencypresswood.com/2026/01/24/bringing-meaning-benefit-to-2026-by-taking-a-vow-of-nonviolence-for-1-day-multiple-days-or-a-full-year/) («FEBRUARY 7th 2027 is LOSAR») [СРЕДНЯЯ] |
| 3 | Шен (Юл Лха) Гутор (27–29/12) | 14–16.02.2026 | **ПОДТВЕРЖДЕНО** | [ravencypresswood](https://ravencypresswood.com/2026/02/07/the-tibetan-new-year-removing-obstacles-of-the-past-and-making-aspirations-for-future-2/): «Tro Phur Gutor... begins on the 27th lunar day and concludes on the evening of the 29th lunar day. In 2026, these dates coincide with February 14th-February 16th» [СРЕДНЯЯ] |
| 3 | Шен (Юл Лха) Гутор (27–29/12) | 03–05.02.2027 | **ПОДТВЕРЖДЕНО (вывод из лунной таблицы)** | 27-й день 12-го мес. = 08.01+26 = 03.02; 29-й день = 05.02 (по лунной таблице ravencypresswood) [СРЕДНЯЯ] |
| 4 | Сидпа Гьялмо Чам (29/12) | 2026-02-16 | **ПОДТВЕРЖДЕНО** | [ravencypresswood](https://ravencypresswood.com/2026/02/07/the-tibetan-new-year-removing-obstacles-of-the-past-and-making-aspirations-for-future-2/): «29th lunar day... In 2026, this date coincides with February 16th» [СРЕДНЯЯ] |
| 4 | Сидпа Гьялмо Чам (29/12) | 2027-02-05 | **ПОДТВЕРЖДЕНО (вывод из лунной таблицы)** | 29-й день 12-го мес. = 05.02.2027 (по лунной таблице ravencypresswood) [СРЕДНЯЯ] |
| 5 | День рождения Тонпы Шенраба (15/12) | 2026-02-01 | **ПОДТВЕРЖДЕНО** | [ravencypresswood](https://ravencypresswood.com/2026/01/31/18043rd-anniversary-of-buddha-tonpa-shenraps-first-deed-the-deed-of-taking-birth-as-a-human-being/): «15th day of the 12th lunar month... In 2026, this lunar day coincides with February 1st» [СРЕДНЯЯ]; [FPYB](https://yungdrungbon.co.uk/2026/02/01/birthday-anniversaries-of-tonpa-shenrab-miwoche-his-son-prince-kongtsa-yungdrung-wangden/): «1st February 2026 marks the 18,043rd anniversary» [ВЫСОКАЯ] |
| 5 | День рождения Тонпы Шенраба (15/12) | 2027-01-22 | **ПОДТВЕРЖДЕНО (вывод из лунной таблицы)** | 22.01.2027 = полнолуние = 15-й день 12-го мес. (лунная таблица ravencypresswood) [СРЕДНЯЯ] |
| 6 | Паринирвана Тонпы Шенраба (30/9) | 2026-11-09 | **ПОДТВЕРЖДЕНО** | [ravencypresswood лунная таблица](https://ravencypresswood.com/2026/01/24/bringing-meaning-benefit-to-2026-by-taking-a-vow-of-nonviolence-for-1-day-multiple-days-or-a-full-year/): 09.11.2026 = новолуние (30-й день 9-го мес.); [FPYB](https://yungdrungbon.co.uk/2025/11/19/9842-anniversary-of-buddha-tonpa-shenrab-miwoches-parinirvana/): «30th day of the 9th month according to the Horda calendar» [ВЫСОКАЯ] |
| 6 | Паринирвана Тонпы Шенраба (30/9) | 2027-11-27 | **НЕ УДАЛОСЬ ПРОВЕРИТЬ напрямую** (астрономически согласуется) | Астрономическое новолуние ноября 2027 = 27–28.11 ([fullmoonology](https://www.fullmoonology.com/new-moon/november-2027/), [Catalina](https://catalina.lpl.arizona.edu/moon-phases/month/2027-11)) — согласуется с 27.11, но прямого бонского источника на 2027 нет |
| 7 | Праздник Прилёта Птиц (15/3) | 2026-05-01 | **НЕ УДАЛОСЬ ПРОВЕРИТЬ название** (дата согласуется) | 01.05.2026 = полнолуние = 15-й день 3-го мес. (лунная таблица ravencypresswood) [СРЕДНЯЯ]; название «Прилёт Птиц» в открытых источниках не найдено |
| 7 | Праздник Прилёта Птиц (15/3) | 2027-05-20 | **НЕ УДАЛОСЬ ПРОВЕРИТЬ название** (дата согласуется) | Полнолуние мая 2027 = 20.05 ([TheSkyLive](https://theskylive.com/moon-calendar?year=2027&month=05), [Griffith](https://griffithobservatory.lacity.gov/explore/observing-the-sky/whats-in-the-sky/the-moon/2027-phases-of-the-moon/), [fullmoon.info](https://www.fullmoon.info/en/fullmoon-calendar/2027.html)) [ВЫСОКАЯ] |
| 8 | Чотрул Дючен (15/1) | 2026-03-03 | **ПОДТВЕРЖДЕНО** | [Sravasti Abbey](https://sravastiabbey.org/losar-and-days-of-miracles-2026/), [danakosha](https://danakosha.org/events/chotrul-duchen-680/), [Siddhartha's Intent](https://siddharthasintent.org/events/chotrul-duchen-virtual-gathering-for-auspiciousness/), [ravencypresswood лунная таблица](https://ravencypresswood.com/2026/01/24/bringing-meaning-benefit-to-2026-by-taking-a-vow-of-nonviolence-for-1-day-multiple-days-or-a-full-year/) (03.03.2026 = полнолуние) [СРЕДНЯЯ] |
| 8 | Чотрул Дючен (15/1) | 2027-02-20 | **ПОДТВЕРЖДЕНО** | [Mönlam Prayers](https://monlam.org/activity/chotrul-duchen-festival-of-buddhas-display-of-miracles/): «February 20, 2027... falls each year on the 1st full moon day of the Tibetan New Year» [СРЕДНЯЯ] |

---

## Расхождения между источниками

1. **Лунный день дня рождения Тонпы Шенраба.** ravencypresswood называет его «15-й день **12-го** лунного месяца»; FPYB — «15-й день **первого** месяца весны». Оба источника сходятся на дате **01.02.2026**. Вероятная причина: разные системы нумерации месяцев (Чжанчжунгская vs Хорда) — в Чжанчжунгской системе 12-й месяц соответствует «первому месяцу весны» Хорды. Дата не оспаривается.

2. **Тибетский Лосар 2027.** Один источник (Facebook «fb-answers») называет 28.02.2027, но это единичный ненадёжный источник; консенсус 5+ независимых источников (GoToTibet, qppstudio, PotalaStore, Tibetan Nuns Project, ravencypresswood) — **07.02.2027**. Расхождение отброшено как ошибка единичного источника.

3. **Пост Shenten Dargye Ling (Facebook)** о Чжан Чжун Лосар упоминает «March 3, 2026» — вероятно, относится к полнолунию/Чотрул Дючен, а не к самому Лосару. Facebook не скрейпится (Firecrawl не поддерживает), пост не верифицирован. Авторитетные источники (ravencypresswood, FPYB) однозначно дают Чжан Чжун Лосар 2026 = 19.01.

---

## Неудачные попытки (журнал анти-loop)

| Действие | Результат | Вывод |
|----------|-----------|-------|
| search «Bird arrival festival Bon 2026 15th day 3rd month» | Только американские фестивали птиц | Название «Прилёт Птиц» не документировано в англоязычных источниках; ветка закрыта |
| search «ravencypresswood bird arrival festival Bon 2026» | Нерелевантно | То же |
| search «Yungdrung Bon bird arrival festival 15th day 3rd month» | Нерелевантно | То же |
| search «Bon festival birds return spring cuckoo 2026» | Японские Bon-фестивали | То же |
| search «ravencypresswood.com bird arrival» | Нет профильной статьи | То же |
| search «Bon cuckoo bird festival 15th day 3rd month 2026» | Нерелевантно | То же |
| search «Bon calendar bird arrival festival 15th day 3rd month» | Нерелевантно | То же |
| scrape Facebook Shenten Dargye Ling | Firecrawl: «we do not support this site» | Facebook не скрейпится; пост не верифицирован |
| search «Sidpa Gyalmo Cham 2027 Bon» | Только общие материалы о Сидпа Гьялмо | Конкретная дата 2027 в будущем, источников нет; закрыто выводом из лунной таблицы |
| search «Zhang Zhung Losar 2027 January» | Нет прямого источника на 2027 | Дата в будущем; закрыто выводом из лунной таблицы ravencypresswood |
| search «parinirvana Tonpa Shenrab 2027» | Нет прямого источника на 2027 | Дата в будущем; закрыто астрономической сверкой (новолуние 27–28.11.2027) |
| search «Tonpa Shenrab birthday 2026 2027 Bon calendar» | HTTP 429 (rate limit) | Транзиентный сбой; повторён с другой формулировкой успешно |

---

## Рекомендации

- **Можно использовать с высокой уверенностью:** все даты 2026 года (пп. 1–8) и Хорда Лосар 2027 (07.02). Они подтверждены минимум двумя независимыми источниками, включая авторитетные (ravencypresswood, FPYB/Тритэн Норбутсе).
- **Даты 2027 года (Чжан Чжун Лосар 08.01, Гутор 03–05.02, Сидпа Гьялмо Чам 05.02, день рождения 22.01)** — подтверждены **выводом** из лунной таблицы ravencypresswood (якоря: 07.01.2027 = новолуние, 22.01 = полнолуние, 07.02 = Лосар). Логика согласована, но прямого источника на 2027 нет (даты в будущем). Рекомендуется перепроверить после публикации календаря на 2027 (обычно ravencypresswood публикует статьи в январе-феврале соответствующего года).
- **Паринирвана 2027 (27.11)** — астрономически согласуется (новолуние 27–28.11.2027), но прямого бонского источника нет. Требует уточнения.
- **Праздник Прилёта Птиц (15/3)** — даты (01.05.2026, 20.05.2027) согласуются с 15-м днём 3-го месяца (полнолуние), но **название праздника не подтверждено** ни одним открытым источником. Требует уточнения: возможно, это внутреннее название проекта или малоизвестный региональный праздник.
- **Авторитетного единого календаря Юнгдрунг Бон на 2026–2027 в открытом доступе нет.** Даты восстанавливаются по ежегодным публикациям ravencypresswood (Nine Ways) и FPYB, а также по лунным таблицам. Для полной верификации 2027 года рекомендуется дождаться публикаций начала 2027 года.

---

## Сырые извлечения

- **ravencypresswood (Чжан Чжун Новый год, 2026-01-17):** «The 1st day of the 12th lunar month is celebrated as New Year's Day according to the custom of the ancient land of Zhang Zhung. In 2026, this date coincides with January 19th... During the period of the Mongol-backed Sakya rule of Tibet, use of the Zhang Zhung based calendrical system was ended... The 1st lunar day of the 1st lunar month was changed to be one month later... In 2026, this lunar day coincides with February 18th.» — https://ravencypresswood.com/2026/01/17/happy-zhang-zhung-new-year/
- **ravencypresswood (Тибетский Новый год, 2026-02-07):** «The Royal Tibetan New Year, known as Losar, is the 1st lunar day of the 1st lunar month. In 2026, this date coincides with February 18th... Tro Phur Gutor Chenmo... begins on the 27th lunar day and concludes on the evening of the 29th lunar day. In 2026, these dates coincide with February 14th-February 16th... the 29th lunar day... In 2026, this date coincides with February 16th.» — https://ravencypresswood.com/2026/02/07/the-tibetan-new-year-removing-obstacles-of-the-past-and-making-aspirations-for-future-2/
- **ravencypresswood (День рождения Тонпы Шенраба, 2026-01-31):** «The 15th day of the 12th lunar month is the 18,043rd birth anniversary... In 2026, this lunar day coincides with February 1st.» — https://ravencypresswood.com/2026/01/31/18043rd-anniversary-of-buddha-tonpa-shenraps-first-deed-the-deed-of-taking-birth-as-a-human-being/
- **FPYB (История Чжан Чжун Лосара):** «In the 13th century, Mongols and Tibetans were at war... the Mongols changed the Zhang Zhung calendar, postponing the new year by one month. This is the system now used to calculate the current Tibetan New Year, and is also known as the Mongolian astrological system, Horda.» — https://yungdrungbon.co.uk/2022/02/02/short-note-on-history-of-zhang-zhung-losar/
- **FPYB (Паринирвана, 2025-11-19):** «Today, on the 30th day of the 9th month according to the Horda (Tib. hor-zla) calendar, we are celebrating the Anniversary of Buddha Tönpa Shenrab Miwoche... achieving nyangen ledepa or parinirvana in 7817 BC.» — https://yungdrungbon.co.uk/2025/11/19/9842-anniversary-of-buddha-tonpa-shenrab-miwoches-parinirvana/
- **ravencypresswood (Лунная таблица года Огненной Лошади):** «March 3rd = FULL MOON... May 1st = FULL MOON... November 9th = NEW MOON... January 7th 2027 = NEW MOON... January 22 = FULL MOON... FEBRUARY 7th 2027 is LOSAR, TIBETAN NEW YEAR.» — https://ravencypresswood.com/2026/01/24/bringing-meaning-benefit-to-2026-by-taking-a-vow-of-nonviolence-for-1-day-multiple-days-or-a-full-year/
- **Mönlam Prayers (Чотрул Дючен 2027):** «February 20, 2027... falls each year on the 1st full moon day of the Tibetan New Year.» — https://monlam.org/activity/chotrul-duchen-festival-of-buddhas-display-of-miracles/