# Исследование: верификация дат календаря Цурпху (mtshur lugs, Карма Кагью) на 2026–2027

Дата исследования: 2026-09-24
Источников проверено: 12 (независимых: 6)
Запросы: 20 формулировок (Firecrawl search) + 3 websearch (fallback при rate-limit 429)
Источник данных: Firecrawl (основной) + websearch (fallback при 429)

## Резюме

Почти все проверяемые даты **ПОДТВЕРЖДЕНЫ** авторитетным источником —
официальным сайтом Karma Kagyu Calendar (karmakagyucalendar.org, «Tsurphu/Tsurlug
calendric system»), который публикует полные списки особых дней на 2026–2027.
Вставной месяц 2027 подтверждён независимым академическим расчётом (arXiv).
Единственное существенное расхождение — даты Кагью Монлам Ченмо (см. ниже).

---

## Найденные данные

### 1. Вставной (intercalary) месяц 2027 — ПОДТВЕРЖДЕНО

| Что | Значение | Источник | Confidence |
|-----|----------|----------|------------|
| Цурпху 2027 — вставной месяц | **9-й** | arXiv «Possible Reforms of the Tibetan Lunisolar Calendar» (формула вставки, Tsurphu E1732/E1852, trigger {0,1}) | [ВЫСОКАЯ] |
| Пхугпа 2027 — вставной месяц | **2-й** | arXiv «Tibetan calendar mathematics» (Janson, Phugpa E1987, trigger {48,49}) | [ВЫСОКАЯ] |

Расчёт (по формулам arXiv, §5.4 / Example 2.8): вставной месяц M в году Y
определяется конгруэнцией `I = 2·M* + β* (mod 65)`, где `M* = 12(Y−Y0)+(M−3)`.
- **Пхугпа** (Y0=1987, β*=0, trigger {48,49}): для Y=2027, M*=477+M, I=44+2M.
  I=48 → M=2. → **вставной 2-й месяц**.
- **Цурпху** (Y0=1732, β*=59, trigger {0,1}): для Y=2027, M*=3537+M, I=48+2M.
  I=1 → M=9. → **вставной 9-й месяц**. (Проверено и для E1852, β*=14 — тот же результат.)

Дополнительно: в 2026 ни у Цурпху, ни у Пхугпа вставного месяца нет (I не попадает
в trigger-множества) — структурно согласуется с утверждением «в 2026 календари
совпадают». Лосар 2026 у обеих традиций = 18.02 (совпадает). Полное подневное
совпадение всех дней 2026 не проверялось (требует полного календаря), но
структурный признак (отсутствие вставного месяца + совпадение Лосара) подтверждён.

### 2. Лосар Цурпху — ПОДТВЕРЖДЕНО

| Что | Значение | Источник | Confidence |
|-----|----------|----------|------------|
| Лосар 2026 | 18.02.2026 | tibettravel.org, karmakagyucalendar FB, sravastiabbey.org | [ВЫСОКАЯ] |
| Лосар 2027 | 07.02.2027 | gototibet.com, tibettravel.org, tnp.org | [ВЫСОКАЯ] |

### 3. Кагью Монлам Ченмо — РАСХОЖДЕНИЕ (см. «Расхождения»)

| Что | Заявлено | Факт (источник) | Confidence |
|-----|----------|-----------------|------------|
| Монлам 2026 | 18.02–04.03.2026 | 40-й Монлам: **23.12.2025–03.01.2026** (Бодх-Гая); 41-й: **13–22.12.2026** | [СРЕДНЯЯ] |
| Монлам 2027 | 07.02–21.02.2027 | фактическое событие 2027 не подтверждено; заявленные даты = традиционный 1-й месяц | [СРЕДНЯЯ] |

### 4. Кутампа (день рождения Будды, 7/4) — ПОДТВЕРЖДЕНО

| Что | Значение | Источник | Confidence |
|-----|----------|----------|------------|
| Кутампа 2026 | 23.05.2026 | karmakagyucalendar.org/special-days/lunar-yearly/kutampa | [ВЫСОКАЯ] |
| Кутампа 2027 | 12.05.2027 | karmakagyucalendar.org (там же) | [ВЫСОКАЯ] |

### 5. Гутор (29/12) — ПОДТВЕРЖДЕНО (по определению + Лосар)

| Что | Значение | Источник | Confidence |
|-----|----------|----------|------------|
| Гутор 2026 | 16.02.2026 | 29-й день 12-го месяца; Лосар 2026=18.02 → 29/12=16.02; определение Гутора — karmakagyucalendar.org | [ВЫСОКАЯ] |
| Гутор 2027 | 05.02.2027 | Лосар 2027=07.02 → 29/12=05.02 | [ВЫСОКАЯ] |

### 6. Чотрул Дючен Цурпху (15/1) — ПОДТВЕРЖДЕНО

| Что | Значение | Источник | Confidence |
|-----|----------|----------|------------|
| Чотрул Дючен 2026 | 03.03.2026 | karmakagyucalendar.org/special-days/duchen/chotrul | [ВЫСОКАЯ] |
| Чотрул Дючен 2027 | 21.02.2027 | karmakagyucalendar.org (там же) | [ВЫСОКАЯ] |

### 7. Сага Дава Дючен (15/4) — ПОДТВЕРЖДЕНО

| Что | Значение | Источник | Confidence |
|-----|----------|----------|------------|
| Сага Дава Дючен 2026 | 31.05.2026 | tnp.org, fpmt.org, wheeloftheyear.com | [ВЫСОКАЯ] |
| Сага Дава Дючен 2027 | 20.05.2027 | monlam.org (Ka-Nying Shedrub Ling) | [ВЫСОКАЯ] |

### 8. Чокхор Дючен (4/6) — ПОДТВЕРЖДЕНО

| Что | Значение | Источник | Confidence |
|-----|----------|----------|------------|
| Чокхор Дючен 2026 | 18.07.2026 | karmakagyucalendar FB, monlam.org, khachodling.org | [ВЫСОКАЯ] |
| Чокхор Дючен 2027 | 07.07.2027 | karmakagyucalendar FB, monlam.org | [ВЫСОКАЯ] |

Уточнение: Чокхор Дючен — **4-й день 6-го месяца** (monlam.org: «4th day of the
6th month»). Запись «4/6» верна, «6/4» — нет.

### 9. Лхабаб Дючен (22/9) — ПОДТВЕРЖДЕНО

| Что | Значение | Источник | Confidence |
|-----|----------|----------|------------|
| Лхабаб Дючен 2026 | 01.11.2026 | karmakagyucalendar.org/special-days/duchen/lhabab; tnp.org; monlam.org | [ВЫСОКАЯ] |
| Лхабаб Дючен 2027 | 22.10.2027 | karmakagyucalendar.org (там же) | [ВЫСОКАЯ] |

### 10. Нгенпа Гу Дзом (7/11) — 2026 ПОДТВЕРЖДЕНО, 2027 НЕ УДАЛОСЬ ПРОВЕРИТЬ

| Что | Значение | Источник | Confidence |
|-----|----------|----------|------------|
| Нгенпа Гу Дзом 2026 | 16.12.2026 | karmakagyucalendar FB («Wednesday, 16 December 2026») | [ВЫСОКАЯ] |
| Нгенпа Гу Дзом 2027 | 06.12.2027 | **не найдено** независимого источника | — |

### 11. Особые дни «из сочетаний элементов» — ВСЕ ПОДТВЕРЖДЕНЫ (точное совпадение списков)

Все четыре списка **побайтово совпадают** с официальными списками
karmakagyucalendar.org (страницы Cyclical Special Days). Это авторитетный
источник именно по Цурпху-календарю.

| День | 2026 (заявлено) | 2027 (заявлено) | Совпадение с источником | Confidence |
|------|-----------------|-----------------|-------------------------|------------|
| **Паден** (неблагоприятен для лунгта) | 26.02, 10.03, 25.03, 06.04, 21.04, 02.05, 15.05, 17.05, 29.05, 10.06, 24.06, 07.07, 21.07, 02.08, 16.08, 29.08, 09.09, 12.09, 24.09, 05.10, 21.10, 01.11, 16.11, 28.11, 13.12 | 05.01, 08.01, 20.01, 01.02 | **точное совпадение** (25+4 дат) | [ВЫСОКАЯ] |
| **Лютеп** (благоприятен для пуджи нагам) | 13.03, 26.03, 01.04, 06.05, 09.05, 21.05, 05.06, 10.06, 23.06, 04.07, 13.08, 23.08, 02.09, 03.09, 19.09, 29.09, 17.10, 23.12 | 17.01, 02.03 | **точное совпадение** (18+2 дат) | [ВЫСОКАЯ] |
| **Ньинак** (чёрный день) | 09.03, 26.03, 09.06, 23.06, 01.08, 08.09, 21.09, 30.10, 08.12 | 21.01 | **точное совпадение** (9+1 дат) | [ВЫСОКАЯ] |
| **Йеконг** | 01.03, 29.03, 25.04, 22.05, 19.06, 17.07, 10.09, 07.10, 03.11, 01.12, 29.12 | 26.01 | **точное совпадение** (11+1 дат) | [ВЫСОКАЯ] |

Примечание: на сайте Karma Kagyu Calendar эти дни называются Paden, Luthep,
Nyinak, Yenkong (раздел «Cyclical Special Days»). В календаре kalacakra.org
(Цурпху) они фигурируют как «yan kwong» (Йеконг), «klu thebs» (Лютеп),
«nyi nag» (Ньинак) — подтверждает, что это штатные элементы Цурпху-системы.

---

## Расхождения между источниками

1. **Кагью Монлам Ченмо (п.3).** Заявленные даты (18.02–04.03.2026 и
   07.02–21.02.2027) — это фактически «Лосар → Чотрул Дючен», т.е. первые 15 дней
   1-го тибетского месяца (традиционное время Монлама). Однако **фактическое**
   событие Kagyu Monlam Chenmo в Бодх-Гае в последние годы проводится в декабре:
   40-й — 23.12.2025–03.01.2026 (kagyumonlam.org, KagyuMonlamOfficial FB),
   41-й — 13–22.12.2026 (buddhistpilgrimagetours.com). Исторически Монлам
   проводился в 1-м месяце (34-й, 2017 — 13.02.2017, kagyuoffice.org), но в
   2022 (Румтек, 14–20.12) и 2025–2026 перенесён на декабрь. **Вывод:** заявленные
   даты отражают традиционное календарное время, но НЕ совпадают с фактическими
   датами современного события. Требует уточнения, какое именно событие имелось
   в виду.

2. **Чотрул Дючен 2027.** karmakagyucalendar.org (Цурпху) даёт 21.02.2027
   (совпадает с заявленным), а monlam.org (Ka-Nying Shedrub Ling, Катманду) —
   20.02.2027. Вероятная причина: разные календарные системы (Цурпху vs иная)
   или пропущенный день. Для Цурпху-календаря верно 21.02.2027.

3. **Лхабаб Дючен 2027.** karmakagyucalendar.org (Цурпху) даёт 22.10.2027
   (совпадает с заявленным). Бутанский календарь 2027 (bhutanesecalendar.com)
   даёт 20.11.2027 — это другая традиция (бутанская), не Цурпху. Для Цурпху
   верно 22.10.2027.

4. **Лхабаб Дючен 2026 (прочие источники).** greattibettour.com даёт 03.11.2026,
   azrscorp.com — 09.11.2026 (разные системы). Авторитетные Цурпху-источники
   (karmakagyucalendar.org, tnp.org, monlam.org) единогласно дают 01.11.2026 —
   совпадает с заявленным.

---

## Неудачные попытки (журнал анти-loop)

| Действие | Результат | Вывод |
|----------|-----------|-------|
| firecrawl search «Tibetan calendar 2027 intercalary month…» | 429 (rate limit) | Транзиентный сбой; повторён позже, успешно |
| firecrawl search «Chotrul Duchen 2026 Saga Dawa…» | 429 | То же |
| firecrawl search «Kutampa Buddha birthday…» | 429 | То же |
| firecrawl search «Tibetan calendar 2027 intercalary month leap month» (повтор) | 429 | Rate limit не спал; переключился на websearch fallback |
| firecrawl search «Lhabab Duchen 2027» (3 формулировки) | Не дал прямой даты 2027 | Закрыто: дата 2027 получена со страницы karmakagyucalendar.org/special-days/duchen/lhabab |
| firecrawl search «Ngenpa Gu Dzom 2027» (2 формулировки) | Не дал прямой даты 2027 | Ветка закрыта: 2026 подтверждена, 2027 — «не удалось проверить» |
| firecrawl scrape karmakagyucalendar.org/special-days/lunar-yearly/gutor | Страница без списка дат (только описание) | Гутор подтверждён по определению (29/12) + датам Лосара |
| firecrawl scrape karmakagyucalendar.org/special-days/lunar-yearly/ngenpa-gu-dzom | Страница без списка дат | Нгенпа Гу Дзом 2027 остался непроверенным |

---

## Рекомендации

- **Можно использовать как подтверждённые:** Лосар (18.02.2026 / 07.02.2027),
  Кутампа (23.05.2026 / 12.05.2027), Гутор (16.02.2026 / 05.02.2027), Чотрул
  Дючен (03.03.2026 / 21.02.2027), Сага Дава Дючен (31.05.2026 / 20.05.2027),
  Чокхор Дючен (18.07.2026 / 07.07.2027), Лхабаб Дючен (01.11.2026 / 22.10.2027),
  вставной месяц 2027 (Цурпху=9, Пхугпа=2), все четыре списка особых дней
  (Паден/Лютеп/Ньинак/Йеконг) — точное совпадение с официальным Karma Kagyu
  Calendar.
- **Требует уточнения:** (а) Кагью Монлам Ченмо — заявленные даты не совпадают
  с фактическим событием (декабрь); уточнить, какое событие имелось в виду;
  (б) Нгенпа Гу Дзом 2027 (06.12.2027) — не найден независимый источник;
  (в) полное подневное совпадение Цурпху и Пхугпа в 2026 — подтверждён только
  структурный признак (нет вставного месяца, Лосар совпадает).
- **Рекомендуемый источник для сверки в будущем:** официальный
  karmakagyucalendar.org (разделы Special Days / Current Calendar) — это
  первоисточник по Цурпху-календарю Карма Кагью.

---

## Сырые извлечения (ключевые цитаты)

- **karmakagyucalendar.org/special-days/cyclical/paden** (Паден):
  «26 February 2026 ⋅ 10 March 2026 ⋅ … ⋅ 13 December 2026 ⋅ 5 January 2027 ⋅
  8 January 2027 ⋅ 20 January 2027 ⋅ 1 February 2027. Unfavourable day for
  putting up Lungta or prayer flag.»
- **karmakagyucalendar.org/special-days/cyclical/luthep** (Лютеп):
  «13 March 2026 ⋅ 26 March 2026 ⋅ … ⋅ 23 December 2026 ⋅ 17 January 2027 ⋅
  2 March 2027. Favourable day, in which pujas for the Naga are done.»
- **karmakagyucalendar.org/special-days/cyclical/nyinak** (Ньинак):
  «9 March 2026 ⋅ 26 March 2026 ⋅ … ⋅ 8 December 2026 ⋅ 21 January 2027. Black Day.»
- **karmakagyucalendar.org/special-days/cyclical/yenkong** (Йеконг):
  «1 March 2026 ⋅ 29 March 2026 ⋅ … ⋅ 29 December 2026 ⋅ 26 January 2027.»
- **karmakagyucalendar.org/special-days/duchen/chotrul** (Чотрул Дючен):
  «…14 March 2025 | 3 March 2026 | 21 February 2027* | 11 March 2028…»
- **karmakagyucalendar.org/special-days/duchen/lhabab** (Лхабаб Дючен):
  «…11 November 2025 | 1 November 2026 | 22 October 2027 | 9 November 2028…»
- **karmakagyucalendar.org/special-days/lunar-yearly/kutampa** (Кутампа):
  «2 June 2025 | 23 May 2026 | 12 May 2027 | 30 May 2028…»
- **karmakagyucalendar.org/special-days/lunar-yearly/gutor** (Гутор):
  «…ends with Mahakala dances and torma offerings on 29th day of 12th Lunar month (Gutor)».
- **arXiv «Possible Reforms of the Tibetan Lunisolar Calendar»** (вставной месяц):
  «Tsurphu (E1732): β*=59, trigger set I∈{0,1}»; «Phugpa (E1987): β*=0, trigger set I∈{48,49}».
- **kagyumonlam.org / KagyuMonlamOfficial FB** (Монлам): «The 40th Kagyu Monlam
  Chenmo - Dec 23, 2025 to Jan 3, 2026 at Bodhgaya».
- **buddhistpilgrimagetours.com** (Монлам 2026): «Kagyu Monlam Chenmo …
  13th December to 22nd December 2026».
- **tnp.org** (Сага Дава Дючен 2026): «In 2026, Saga Dawa Düchen is on May 31st».
- **monlam.org** (Сага Дава Дючен 2027): «Saga Dawa Düchen … May 20, 2027».
- **karmakagyucalendar FB** (Чокхор Дючен 2027): «Chökhor Düchen: Wednesday,
  7 July 2027»; (Нгенпа Гу Дзом 2026): «Ngenpa Gu Dzom: Wednesday, 16 December 2026».

---

## Список источников (URL)

1. https://www.karmakagyucalendar.org/special-days/cyclical/paden
2. https://www.karmakagyucalendar.org/special-days/cyclical/luthep
3. https://www.karmakagyucalendar.org/special-days/cyclical/nyinak
4. https://www.karmakagyucalendar.org/special-days/cyclical/yenkong
5. https://www.karmakagyucalendar.org/special-days/duchen/chotrul
6. https://www.karmakagyucalendar.org/special-days/duchen/lhabab
7. https://www.karmakagyucalendar.org/special-days/lunar-yearly/kutampa
8. https://www.karmakagyucalendar.org/special-days/lunar-yearly/gutor
9. https://www.karmakagyucalendar.org/current-calendar
10. https://arxiv.org/html/2604.01233v2 (Possible Reforms of the Tibetan Lunisolar Calendar)
11. https://doi.org/10.48550/arxiv.1401.6285 (Svante Janson, Tibetan calendar mathematics)
12. https://kagyumonlam.org/ (Kagyu Monlam)
13. https://www.buddhistpilgrimagetours.com/public/uploads/Annual-Festival-List-2026-27.pdf
14. https://tnp.org/important-tibetan-buddhist-holidays-in-2026/
15. https://fpmt.org/edu-news/saka-dawa-duchen-2026-sunday-may-31/
16. https://monlam.org/calendar/auspicious-days/
17. https://www.tibettravel.org/tibetan-calendar/tibetan-festival-calendar-2014.html
18. https://www.gototibet.com/travel-guide/tibetan-new-year-date.html
19. https://sravastiabbey.org/losar-and-days-of-miracles-2026/
20. http://www.kalacakra.org/calendar/os_tsurphu.htm (Цурпху-календарь, спец. дни)
21. https://www.facebook.com/karmakagyucalendar/ (официальная страница Karma Kagyu Calendar)