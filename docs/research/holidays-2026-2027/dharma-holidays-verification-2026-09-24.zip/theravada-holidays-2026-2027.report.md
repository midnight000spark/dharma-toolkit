# Исследование: Верификация дат тхеравадинских праздников 2026 и 2027

Дата исследования: 2026-09-24
Источников проверено: ~25 (независимых: ~15)
Запросы: Magha Puja 2026/2027; Visakha Bucha 2026/2027; Asalha Puja 2026/2027;
Khao Phansa / Ok Phansa 2026/2027; Anapanasati Day 2026/2027; full moon
July/October/November 2026/2027; Thai lunar calendar adhikamasa leap month;
Loi Krathong 2026/2027; официальные тайские праздники 2026/2027.
Источник данных: Firecrawl (search) + fallback websearch (часть запросов из-за
rate-limit 429 Firecrawl; отмечено в тексте).

---

## Итоговая таблица

| Событие | Год | Заявленная дата | Найденная дата | Вердикт | Источник |
|---------|-----|-----------------|----------------|---------|----------|
| Магха Пуджа (Makha Bucha) | 2026 | 2026-03-03 | 2026-03-03 | **ПОДТВЕРЖДЕНО** | MFA Thailand, BCCT, timeanddate, thai_lunar.dart |
| Магха Пуджа | 2027 | 2027-02-21 | 2027-02-21 | **ПОДТВЕРЖДЕНО** | timeout.com (офиц. 2027), calendarlabs, calendarhours |
| Висакха Пуджа (Visakha Bucha) | 2026 | 2026-05-31 | 2026-05-31 | **ПОДТВЕРЖДЕНО** | MFA Thailand, BCCT, timeanddate, thailandnow |
| Висакха Пуджа | 2027 | 2027-05-20 | 2027-05-20 | **ПОДТВЕРЖДЕНО** | timeout.com (офиц. 2027), officeholidays, calendarlabs |
| Асалха Пуджа (Asalha Bucha) | 2026 | 2026-07-29 | 2026-07-29 | **ПОДТВЕРЖДЕНО** | MFA Thailand, BCCT, timeanddate, thailunar |
| Асалха Пуджа | 2027 | 2027-07-19 | 2027-07-18 (офиц./большинство); 2027-07-19 (меньшинство) | **НЕ УДАЛОСЬ ПРОВЕРИТЬ однозначно** — расхождение на 1 день | timeout.com (офиц. 2027), calendarlabs, globalholidayscalendar → 18-е; officeholidays, backpackingtours → 19-е |
| Начало Вассы (Khao Phansa) | 2026 | 2026-07-30 | 2026-07-30 | **ПОДТВЕРЖДЕНО** | thailandnow, publicholidays.asia, thai_lunar.dart |
| Начало Вассы | 2027 | 2027-07-20 | 2027-07-19 (офиц./большинство); 2027-07-20 (меньшинство) | **НЕ УДАЛОСЬ ПРОВЕРИТЬ однозначно** — расхождение на 1 день | timeout.com (офиц. 2027), globalholidayscalendar → 19-е; publicholidays.asia → 20-е |
| Паварана / Ok Phansa | 2026 | 2026-10-26 | 2026-10-26 | **ПОДТВЕРЖДЕНО** | thailandee, thaiholidayguide, Wikipedia, astronomy.com |
| Паварана / Ok Phansa | 2027 | 2027-10-15 | 2027-10-15 | **ПОДТВЕРЖДЕНО** | Catalina, timeandspace, theskylive (полнолуние 15.10), backpackingtours |
| День Анапанасати | 2026 | 2026-11-05 | 2026-11-24 (полнолуние 12-го месяца) / 24–25.11 (тайский календарь) | **ОПРОВЕРГНУТО** — 05.11 не является полнолунием | Catalina, almanac, astronomy.com, mekongregion, destinationthailand |
| День Анапанасати | 2027 | 2027-11-14 | 2027-11-14 | **ПОДТВЕРЖДЕНО** | umetravel, mapofthailand, destinationthailand (Loi Krathong 14.11) |

---

## Детальные вердикты

### 1. Магха Пуджа / Makha Bucha
- **2026-03-03 — ПОДТВЕРЖДЕНО.** Официальный тайский календарь (MFA Thailand PDF,
  BCCT, timeanddate): Makha Bucha = вторник 3 марта 2026. Совпадает с астрономическим
  полнолунием 3 марта 2026 (Worm Moon, astronomy.com). В 2026 (високосный лунный год)
  Магха сдвинута с месяца 3 на месяц 4 — thai_lunar.dart: `fullMoonOf(2026, 4) = 2026-03-03`.
- **2027-02-21 — ПОДТВЕРЖДЕНО.** timeout.com (официальный календарь 2027): воскресенье
  21 февраля 2027. calendarlabs, calendarhours, countuntil — то же. Примечание: индийский
  календарь (drikpanchang) даёт Magha Purnima 2027 = 20 февраля — расхождение систем
  (см. §«Система календаря»).

### 2. Висакха Пуджа / Visakha Bucha
- **2026-05-31 — ПОДТВЕРЖДЕНО.** Официальный тайский календарь (MFA, BCCT,
  timeanddate): воскресенье 31 мая 2026 (замещающий выходной 1 июня). thailandnow:
  «полнолуние шестого лунного месяца» (в високосный год — месяц 7). thai_lunar.dart:
  `fullMoonOf(2026, 7) = 2026-05-31`. Астрономическое полнолуние 31 мая 2026 (Blue Moon).
  ⚠️ calendardate.com ошибочно даёт 1 мая 2026 — не учёл високосный месяц; отброшен.
- **2027-05-20 — ПОДТВЕРЖДЕНО.** timeout.com (офиц. 2027): четверг 20 мая 2027.
  officeholidays, calendarlabs — то же.

### 3. Асалха Пуджа / Asalha Bucha
- **2026-07-29 — ПОДТВЕРЖДЕНО.** Официальный тайский календарь (MFA, BCCT,
  timeanddate): среда 29 июля 2026. В високосный год Асалха попадает во ВТОРОЙ месяц 8
  (8-8): thailunar `2026-07-29 month 8-8 (leap-month year: true)`. Астрономическое
  полнолуние 29 июля 2026 (Buck Moon).
- **2027-07-19 — НЕ УДАЛОСЬ ПРОВЕРИТЬ однозначно (расхождение на 1 день).**
  - За 18 июля: timeout.com (офиц. календарь 2027, «Asalha Bucha Day, Sunday July 18»),
    calendarlabs (18.07), globalholidayscalendar (18.07), siamwithme (18.07),
    thailunar-библиотека (`2027-07-18 month 8, leap-month year: false`),
    астрономическое полнолуние июля 2027 = 18 июля (timeanddate, timeandspace, theskylive).
  - За 19 июля: officeholidays (Mon Jul 19), backpackingtours (полнолуние-партия сдвинута
    на 20.07 «for Asahna Bucha» → Асалха 19.07).
  - Вывод: большинство источников и официальный календарь 2027 (timeout) дают 18 июля.
    Заявленная дата 19 июля поддерживается меньшинством. Вероятная причина расхождения —
    разница между астрономическим полнолунием и официальным тайским календарём (тайский
    календарь иногда ставит полнолуние на день позже астрономического). Официальный список
    2027 мог ещё не быть финализирован Кабинетом на дату исследования (globalholidayscalendar
    помечает буддийские даты 2027 как «astronomical estimates until the Cabinet publishes»).

### 4. Начало Вассы / Khao Phansa (день после Асалха)
- **2026-07-30 — ПОДТВЕРЖДЕНО.** thailandnow: «четверг 30 июля 2026». publicholidays.asia:
  30 июля 2026. thai_lunar.dart: `khaoPhansa = asalha + 1 день = 2026-07-30`.
- **2027-07-20 — НЕ УДАЛОСЬ ПРОВЕРИТЬ однозначно (расхождение на 1 день).**
  - За 19 июля: timeout.com (офиц. 2027, «Buddhist Lent Day, Monday July 19»),
    globalholidayscalendar (19.07), chiangmaitravelhub (19.07), siamwithme (19.07).
  - За 20 июля: publicholidays.asia (20 июля 2027).
  - Вывод: большинство и официальный календарь 2027 дают 19 июля. Заявленная дата 20 июля
    поддерживается меньшинством. Согласуется с расхождением по Асалха 2027 (18 vs 19).

### 5. Паварана / Ok Phansa (конец Вассы)
- **2026-10-26 — ПОДТВЕРЖДЕНО.** thailandee (26/10/2026), thaiholidayguide (26 октября 2026),
  Wikipedia Wan Ok Phansa (26 октября 2026). Астрономическое полнолуние 26 октября 2026
  (Hunter's Moon, astronomy.com).
- **2027-10-15 — ПОДТВЕРЖДЕНО.** Астрономическое полнолуние октября 2027 = 15 октября
  (Catalina, timeandspace, theskylive, moongiant, Griffith). backpackingtours: полнолуние-
  партия сдвинута на 16.10 «for Ok Phansa» → Ok Phansa 15.10. ⚠️ mapofthailand ошибочно
  даёт 25 октября 2027 — противоречит астрономическому полнолунию; отброшен.

### 6. День Анапанасати (полнолуние 12-го лунного месяца)
- **2026-11-05 — ОПРОВЕРГНУТО.** 5 ноября 2026 НЕ является полнолунием: по Catalina это
  Waning Crescent; астрономическое полнолуние ноября 2026 = 24 ноября (Catalina, almanac,
  astronomy.com, fullmoonology, svcs.bg). Полнолуние 12-го лунного месяца (Loi Krathong)
  в 2026 = 24 ноября (mekongregion, destinationthailand) или 25 ноября (mapofthailand,
  umetravel) — источники расходятся на день. В любом случае это НЕ 5 ноября.
  Правильная дата полнолуния 12-го тхеравадинского месяца в 2026 — **24 ноября**
  (астрономически) / 24–25 ноября (тайский календарь).
  ⚠️ RE:ONLINE (reonline.org.uk) даёт «Anapanasati Day 5 November 2026», но его описание
  привязано к Паваране/Катхине, а не к полнолунию 12-го месяца; дата не подтверждается
  астрономией и тайским календарём — источник ненадёжен.
- **2027-11-14 — ПОДТВЕРЖДЕНО.** Полнолуние 12-го лунного месяца (Loi Krathong) 2027 =
  14 ноября (umetravel, mapofthailand, destinationthailand). Совпадает с заявленной датой.

---

## Система календаря и високосный месяц (adhikamāsa)

**Система: ТАЙСКИЙ лунный календарь** (Thai lunar calendar, алгоритм Suriyayatra,
«ปฏิทินหลวง»). Все заявленные даты 2026 и большинство 2027 соответствуют именно тайской
системе (официальные тайские источники MFA/BCCT, тайские лунные библиотеки thai_lunar.dart,
thailunar). Другие системы дают иные даты:
- Индийский календарь: Magha Purnima 2027 = 20 февраля (drikpanchang) против тайского 21 февраля.
- Мьянма/Шри-Ланка используют собственные лунные календари, которые могут расходиться с тайским
  на день и более (Wikipedia Magha Puja: в Мьянме — полнолуние Tabaung, последнего месяца
  бирманского календаря).

**Adhikamāsa (високосный лунный месяц):**
- **2026 — ДА, високосный лунный год (adhikamāsa / อธิกมาส).** Удвоен 8-й месяц (8-8,
  «เดือนแปดหลัง»), год = 384 дня. Подтверждено: thai_lunar.dart (`isAthikamat(2026)=true`),
  goichi-dev/thai-lunar (2026 = อธิกมาส), KranaxALT/thailunar (`2026 leap-month year: true`),
  Wikipedia Thai lunar calendar. В високосный год праздники сдвигаются: Магха 3→4, Висакха 6→7,
  Асалха → второй месяц 8. Заявленные даты 2026 (03-03, 05-31, 07-29) корректно учитывают
  этот сдвиг.
- **2027 — НЕТ, обычный лунный год.** KranaxALT/thailunar: `2027 leap-month year: false`,
  Асалха в месяце 8 (не 8-8).

---

## Расхождения между источниками

1. **Асалха Пуджа 2027: 18 vs 19 июля.** Большинство (timeout-офиц., calendarlabs,
   globalholidayscalendar, siamwithme, thailunar, астрономия) — 18 июля; меньшинство
   (officeholidays, backpackingtours) — 19 июля. Заявленная дата 19 июля в меньшинстве.
   Причина: разница астрономического полнолуния и официального тайского календаря; список
   2027 мог не быть финализирован Кабинетом на дату исследования.
2. **Khao Phansa 2027: 19 vs 20 июля.** Следствие расхождения №1 (день после Асалха).
   Большинство — 19 июля; publicholidays.asia — 20 июля.
3. **Loi Krathong / полнолуние 12-го месяца 2026: 24 vs 25 ноября.** mekongregion,
   destinationthailand — 24 ноября; mapofthailand, umetravel — 25 ноября. Астрономическое
   полнолуние — 24 ноября.
4. **Visakha Bucha 2026: calendardate.com даёт 1 мая** (ошибка — не учтён високосный месяц);
   все остальные источники — 31 мая. calendardate отброшен.
5. **Ok Phansa 2027: mapofthailand даёт 25 октября** (ошибка); астрономия и backpackingtours —
   15 октября. mapofthailand отброшен.
6. **Anapanasati Day 2026: RE:ONLINE даёт 5 ноября**, но это не полнолуние; источник
   ненадёжен, отброшен.

---

## Неудачные попытки (журнал анти-loop)

- Firecrawl `search` → 429 (rate limit) на запросах «Magha Puja 2027», «Khao Phansa 2027»,
  «Anapanasati Day 2026» → вывод: транзиентный лимит; переключился на fallback websearch
  (отмечено в шапке отчёта). Повторных заходов с тем же классом исхода не делал.
- calendardate.com (Visakha 2026 = 1 мая) → противоречит всем остальным и астрономии →
  ветка закрыта как ошибочный источник.
- mapofthailand (Ok Phansa 2027 = 25 октября) → противоречит астрономическому полнолунию
  (15.10) → ветка закрыта как ошибочный источник.
- RE:ONLINE (Anapanasati 2026 = 5 ноября) → не подтверждается астрономией (05.11 не
  полнолуние) → ветка закрыта как ненадёжный источник.
- Официальный список тайских праздников 2027: timeout.com (2026-09-22) заявляет «official»,
  но globalholidayscalendar помечает буддийские даты 2027 как «astronomical estimates until
  the Cabinet publishes» → финальная верификация 2027 (Асалха/Khao Phansa) остаётся
  неоднозначной до публикации официального списка Кабинета.

---

## Рекомендации

- **Использовать как подтверждённые:** Магха 2026-03-03 / 2027-02-21; Висакха 2026-05-31 /
  2027-05-20; Асалха 2026-07-29; Khao Phansa 2026-07-30; Ok Phansa 2026-10-26 / 2027-10-15;
  Анапанасати 2027-11-14.
- **Исправить в архиве проекта:** Анапанасати 2026 — заявленное 05.11 неверно (не полнолуние);
  правильная дата полнолуния 12-го месяца — **24 ноября 2026** (или 24–25.11 по тайскому
  календарю). Рекомендуется уточнить, какое именно определение «Дня Анапанасати» используется
  в проекте (полнолуние 12-го месяца vs. дата, привязанная к Паваране/Катхине).
- **Перепроверить перед релизом:** Асалха 2027 (18 vs 19 июля) и Khao Phansa 2027 (19 vs 20 июля)
  — после публикации официального списка тайского Кабинета на 2027. На дату исследования
  большинство источников и официальный календарь (timeout) дают 18/19 июля, что на день раньше
  заявленного.
- **Учесть систему календаря:** даты соответствуют ТАЙСКОМУ календарю. Если проект нацелен на
  Мьянму/Шри-Ланку/Индию — даты могут отличаться (пример: индийская Magha Purnima 2027 = 20.02).
- **Високосный месяц:** 2026 — adhikamāsa (удвоенный 8-й месяц), 2027 — обычный год. Это уже
  корректно отражено в заявленных датах 2026.

---

## Сырые извлечения (ключевые цитаты)

- **MFA Thailand (офиц. 2026):** «Makha Bucha Day — Tue 03-Mar; Visakha Bucha Day — Sun 31-May
  (substitution Mon 01-Jun); Asalha Bucha Day — Wed 29-Jul». URL: image.mfa.go.th (Holidays2026ENG.pdf)
- **BCCT Thailand (офиц. 2026):** «Tue 03-Mar Makha Bucha Day; Mon 01-Jun Substitution for Visakha
  Bucha Day (Sunday 31th May); Wed 29-Jul Asarnha Bucha Day». URL: members.bccthai.com
- **timeout.com (офиц. 2027, 2026-09-22):** «Sunday February 21: Makha Bucha Day; Thursday May 20:
  Visakha Bucha Day; Sunday July 18: Asalha Bucha Day; Monday July 19: Buddhist Lent Day».
  URL: timeout.com/bangkok/news/the-thailand-2027-public-holidays-092326
- **thai_lunar.dart (README):** «isAthikamat(2026, era: ThaiEra.ce) // true (leap month: doubled
  month 8); fullMoonOf(2026, 4) // Makha 2026-03-03; fullMoonOf(2026, 7) // Visakha 2026-05-31;
  fullMoonOf(2026, 8, secondEighth: true) // Asalha 2026-07-29; khaoPhansa = asalha + 1 // 2026-07-30».
  URL: github.com/ultramcu/thai_lunar.dart
- **KranaxALT/thailunar (README):** «2026: 2026-07-29 month 8-8 (leap-month year: true);
  2027: 2027-07-18 month 8 (leap-month year: false)». URL: pkg.go.dev/github.com/KranaxALT/thailunar
- **astronomy.com (полнолуния 2026):** «Tuesday, March 3 — Worm Moon; Sunday, May 31 — Blue Moon;
  Wednesday, July 29 — Buck Moon; Monday, Oct. 26 — Hunter's Moon; Tuesday, Nov. 24 — Beaver Moon».
  URL: astronomy.com/observing/full-moon-calendar-dates-times-types
- **timeandspace.science (полнолуния 2027):** «Full moon July 18, 2027 15:44 UTC; Full moon
  October 15, 2027 13:46 UTC». URL: timeandspace.science/moon/calendar/july-2027 и /october-2027
- **Catalina Sky Survey (ноябрь 2026):** «Full Moon Tuesday, November 24th, 2026; Nov 5 = Waning
  Crescent». URL: catalina.lpl.arizona.edu/moon-phases/month/2026-11
- **mekongregion.com (Loi Krathong):** «2026-Nov-24, Tuesday; 2027-Nov-13, Saturday». URL:
  mekongregion.com/mekong-region-festivals/loy-krathong
- **umetravel.com (Loi Krathong):** «Loy Krathong 2026 — Wednesday, November 25, 2026; 2027 —
  Sunday, November 14, 2027». URL: umetravel.com/loy-krathong-festival/dates.html
- **backpackingtours.com (полнолуние-партии 2027):** «Tue 20 Jul 2027 — Moved for Asahna Bucha;
  Sat 16 Oct 2027 — Moved a day for Ok Phansa; Sat 13 Nov 2027 — Full moon». URL:
  backpackingtours.com/blog/full-moon-party-dates
- **Wikipedia Thai lunar calendar:** «A 384-day-long year repeats the 30-day-long 8th month…
  called an extra-month year (อธิกมาส, athikamat)». URL: en.wikipedia.org/wiki/Thai_lunar_calendar
- **drikpanchang (индийский календарь):** «Magha Purnima on Saturday, February 20, 2027». URL:
  drikpanchang.com/purnima/magha/magha-purnima-date-time.html